public class EightThree {
    public static void main(String[] args) {
        int arr[][] = new int[6][10];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < i; j++) {
                arr[i][j] = i;
            }
        }


        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
        sec();
    }

    public static void sec() {
        int arr[][] = new int[6][10];

        // Заполняем массив
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5 - i; j++) {
                arr[i][j] = 5 + i; // Заполняем нужными значениями
            }
        }

        // Выводим массив
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5 - i; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
        third();
    }
    public static void third() {
        int arr[][] = new int[6][10];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < i; j++) {
                arr[i][j] = i*10;
            }
        }
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
        four();
    }
    public static void four() {
        int arr[][] = new int[6][10];

        // Заполняем массив
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5 - i; j++) {
                arr[i][j] = 5 * (i+1); // Заполняем нужными значениями
            }
        }

        // Выводим массив
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5 - i; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }
}