public class SixTwo {
    public static void main(String[] args) {
        int sum = 0;
        int arr[] = new int[12];

        for (int i = 0; i < arr.length; i++) {
            arr[i] = 10 - i;
            System.out.println(arr[i]);
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i]>0) {
                sum += arr[i];
            }
        }

        System.out.println("Sum: " + sum);
    }
}
