import java.util.Random;
public class SevenTwentySix {
        public static void main(String[] args) {
            Random random = new Random();
            int min = -10;
            int max = 10;
            int sum = 0;
            int arr[] = new int[30];
            for (int i = 0; i < arr.length; i++) {
                arr[i] =random.nextInt(max - min + 1) + min;
                System.out.println(arr[i]);
            }
            for (int i = 0; i < arr.length; i++) {
                if (arr[i]<0) {
                    sum += 1;
                }
            }
            System.out.println("Sum: "+sum);

        }
}



