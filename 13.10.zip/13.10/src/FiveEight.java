public class FiveEight {
    public static void main(String[] args) {
        for (int i = 1; i < 11; i++) {
            System.out.println(i*0.453);
        }
    }
}
