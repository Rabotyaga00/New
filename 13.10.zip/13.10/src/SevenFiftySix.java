import java.util.Scanner;

public class SevenFiftySix {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Введите количество городов:");
        int N = scan.nextInt();
        if (N <= 0) {
            System.out.println("Количество городов должно быть положительным.");
            return;
        }

        int[] distances = new int[N];
        System.out.println("Введите расстояния от Москвы до городов:");
        for (int i = 0; i < N; i++) {
            distances[i] = scan.nextInt();
        }

        int maxDistance = findMaxDistance(distances);
        System.out.println("Расстояние до самого удаленного города: " + maxDistance);
    }

    public static int findMaxDistance(int[] distances) {
        int max = distances[0];
        for (int distance : distances) {
            if (distance > max) {
                max = distance;
            }
        }
        return max;
    }
}
