import java.util.Scanner;

public class five_thirteen {
    public static void main(String[] args) {
        for (int i = 1; i <10; i++) {
            int mul = 7*i;
            System.out.println(7+"*"+i+"="+ mul);
        }
    }
}
