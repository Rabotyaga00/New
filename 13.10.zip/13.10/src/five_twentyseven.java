import java.util.Scanner;

public class five_twentyseven {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 100; i <= 500; i++) {
            sum += i;
        }
        System.out.println("Сумма чисел: " + sum);

        second();
    }

    public static void second () {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите певрвое число:" );
        int fir = scanner.nextInt();
        System.out.println("Введите второе число:" );
        int sec = scanner.nextInt();
        int sum = 0;
        for (int i = fir; i <= sec; i++) {
            sum += i;
        }
        System.out.println("Сумма чисел: " + sum);
    }
}