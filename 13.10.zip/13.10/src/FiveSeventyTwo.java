public class FiveSeventyTwo {
    public static void main(String[] args) {
        float sum =10;
        float dist = 10;
        for (int i = 2; i < 11; i++) {
            dist *= 1.1;
            sum += dist;
            System.out.println(dist);
        }
        System.out.println(sum);
    }
}
