import java.util.Scanner;

public class FiveTwentyEight {
    public static void main(String[] args) {
        int sum = 8;
        for (int i =9; i <= 15; i++) {
            sum *= i;
        }
        System.out.println("Произведение чисел: " + sum);

        second();
    }

    public static void second () {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите певрвое число:" );
        int fir = scanner.nextInt();
        System.out.println("Введите второе число:" );
        int sec = scanner.nextInt();
        int mul = 1;
        for (int i = fir; i <= sec; i++) {
            mul *= i;
        }
        System.out.println("Произведение чисел: " + mul);
    }
}
