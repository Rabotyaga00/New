public class EightOne {
    public static void main(String[] args) {
        int arr[][] = new int[4][6];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 6; j++) {
                arr[i][j] = 5;
            }
        }

        // Выводим первый массив
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println(); // Переход на новую строку после каждой строки массива
        }

        // Вызываем метод sec без аргументов, так как он не используется
        sec();
    }

    public static void sec() {
        int arr[][] = new int[4][10];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 10; j++) { // Изменен цикл для правильной индексации
                arr[i][j] = j + 1; // Заполняем массив значениями от 1 до 10
            }
        }

        // Выводим второй массив
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println(); // Переход на новую строку после каждой строки массива
        }
        third();
    }

    public static void third() {
        int k = 41;
        int arr[][] = new int[4][10];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 10; j++) {
                    arr[i][j] = k;
                    k++;
                }
        }

        // Выводим первый массив
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println(); // Переход на новую строку после каждой строки массива
        }

    }
}
