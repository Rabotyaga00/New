public class SixTwentyOne {
    public static void main(String[] args) {
        int sum = 0;
        int sum1 = 0;
        int arr[] = new int[20];

        arr[0] = 0;
        arr[1] = 1;

        for (int i = 2; i < 20; i++) {
            arr[i] = arr[i - 1] + arr[i - 2];
            System.out.println(arr[i]);
        }
        
        for (int i = 0; i < 20; i++) {
            if (arr[i] < 1001) {
                sum1 += arr[i];
            }
        }

        System.out.println("Sum :" + sum1);
    }
}
